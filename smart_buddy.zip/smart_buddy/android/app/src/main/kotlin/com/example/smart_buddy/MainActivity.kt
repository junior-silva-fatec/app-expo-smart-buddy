package com.example.smart_buddy

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
