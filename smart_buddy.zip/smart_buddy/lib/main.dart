import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

void main() {
  runApp(SmartBuddyApp());
}

class SmartBuddyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: HomePage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<dynamic> events = []; // Lista para armazenar os eventos
  String? loggedInEmail; // Armazena o email do usuário logado

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Smart Buddy'),
        centerTitle: true,
        backgroundColor: Colors.blueAccent,
        actions: [
          TextButton(
            onPressed: () {
              _showLoginModal(context);
            },
            child: Text(
              'Login',
              style: TextStyle(
                color: Colors.white,
                fontSize: 16,
              ),
            ),
          ),
        ],
      ),
      body: events.isEmpty
          ? Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Smart Buddy',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.blueAccent,
              ),
            ),
            SizedBox(height: 10),
            Text(
              'Organize seu tempo, transforme sua vida.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 16, color: Colors.grey),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                _showSignUpModal(context);
              },
              child: Text('Criar Conta'),
            ),
          ],
        ),
      )
          : ListView.builder(
        itemCount: events.length,
        itemBuilder: (context, index) {
          final event = events[index];
          return Card(
            margin: EdgeInsets.all(8.0),
            child: ListTile(
              title: Text(event['title'] ?? 'Sem título'),
              subtitle: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Descrição: ${event['description'] ?? 'Sem descrição'}'),
                  Text('Data: ${event['date'] ?? 'Sem data'}'),
                  Text('Duração: ${event['duration'] ?? 'Sem duração'}'),
                  Text('Horário: ${event['time'] ?? 'Sem horário'}'),
                ],
              ),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    icon: Icon(Icons.edit, color: Colors.blue),
                    onPressed: () {
                      _editEvent(context, event);
                    },
                  ),
                  IconButton(
                    icon: Icon(Icons.delete, color: Colors.red),
                    onPressed: () {
                      _deleteEvent(context, event['_id'], index);
                    },
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Future<bool> _login(BuildContext context, String email, String password) async {
    const String loginUrl =
        'https://web-qx4yu7fnv0m1.up-us-nyc1-k8s-1.apps.run-on-seenode.com/login';

    if (email.isEmpty || password.isEmpty) {
      _showAlert(context, 'Por favor, preencha todos os campos.');
      return false;
    }

    try {
      final response = await http.post(
        Uri.parse(loginUrl),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'email': email, 'password': password}),
      );

      if (response.statusCode == 200) {
        _showAlert(context, 'Login realizado com sucesso!');
        setState(() {
          loggedInEmail = email; // Armazena o email do usuário logado
        });
        return true;
      } else {
        final responseBody = jsonDecode(response.body);
        final errorMessage = responseBody['message'] ?? 'Erro desconhecido';
        _showAlert(context, errorMessage);
        return false;
      }
    } catch (e) {
      _showAlert(context, 'Erro ao fazer login: $e');
      return false;
    }
  }

  Future<void> _fetchEvents(BuildContext context) async {
    try {
      final response = await http.get(
        Uri.parse(
            'https://web-qx4yu7fnv0m1.up-us-nyc1-k8s-1.apps.run-on-seenode.com/events'),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data is List) {
          setState(() {
            events = data.where((event) => event['owner'] == loggedInEmail).toList();
          });
        } else {
          _showAlert(context, 'A resposta não é uma lista válida.');
        }
      } else {
        _showAlert(context, 'Erro ao buscar eventos: ${response.body}');
      }
    } catch (e) {
      _showAlert(context, 'Erro: $e');
    }
  }

  void _showLoginModal(BuildContext context) {
    final TextEditingController emailController = TextEditingController();
    final TextEditingController passwordController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Login'),
          content: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextField(
                  controller: emailController,
                  decoration: InputDecoration(
                    labelText: 'Email',
                    border: OutlineInputBorder(),
                  ),
                  keyboardType: TextInputType.emailAddress,
                ),
                SizedBox(height: 10),
                TextField(
                  controller: passwordController,
                  decoration: InputDecoration(
                    labelText: 'Senha',
                    border: OutlineInputBorder(),
                  ),
                  obscureText: true,
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(); // Fechar modal
              },
              child: Text('Cancelar'),
            ),
            ElevatedButton(
              onPressed: () async {
                final isSuccess = await _login(
                  context,
                  emailController.text.trim(),
                  passwordController.text.trim(),
                );
                if (isSuccess) {
                  await _fetchEvents(context); // Busca eventos após login
                }
                Navigator.of(context).pop(); // Fechar modal
              },
              child: Text('Login'),
            ),
          ],
        );
      },
    );
  }

  void _showSignUpModal(BuildContext context) {
    final TextEditingController firstNameController = TextEditingController();
    final TextEditingController lastNameController = TextEditingController();
    final TextEditingController emailController = TextEditingController();
    final TextEditingController passwordController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Criar Conta'),
          content: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextField(
                  controller: firstNameController,
                  decoration: InputDecoration(labelText: 'Nome'),
                ),
                SizedBox(height: 10),
                TextField(
                  controller: lastNameController,
                  decoration: InputDecoration(labelText: 'Sobrenome'),
                ),
                SizedBox(height: 10),
                TextField(
                  controller: emailController,
                  decoration: InputDecoration(labelText: 'Email'),
                  keyboardType: TextInputType.emailAddress,
                ),
                SizedBox(height: 10),
                TextField(
                  controller: passwordController,
                  decoration: InputDecoration(labelText: 'Senha'),
                  obscureText: true,
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('Cancelar'),
            ),
            ElevatedButton(
              onPressed: () async {
                await _signUp(
                  context,
                  firstNameController.text.trim(),
                  lastNameController.text.trim(),
                  emailController.text.trim(),
                  passwordController.text.trim(),
                );
              },
              child: Text('Criar Conta'),
            ),
          ],
        );
      },
    );
  }

  Future<void> _signUp(BuildContext context, String firstName, String lastName,
      String email, String password) async {
    const String signUpUrl =
        'https://web-qx4yu7fnv0m1.up-us-nyc1-k8s-1.apps.run-on-seenode.com/users';

    if (firstName.isEmpty ||
        lastName.isEmpty ||
        email.isEmpty ||
        password.isEmpty) {
      _showAlert(context, 'Por favor, preencha todos os campos.');
      return;
    }

    try {
      final response = await http.post(
        Uri.parse(signUpUrl),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'firstName': firstName,
          'lastName': lastName,
          'email': email,
          'password': password,
        }),
      );

      if (response.statusCode == 201) {
        _showAlert(context, 'Conta criada com sucesso!');
        Navigator.of(context).pop(); // Fechar o modal após criar conta
      } else {
        final responseBody = jsonDecode(response.body);
        final errorMessage = responseBody['message'] ?? 'Erro desconhecido';
        _showAlert(context, errorMessage);
      }
    } catch (e) {
      _showAlert(context, 'Erro ao criar conta: $e');
    }
  }

  void _showAlert(BuildContext context, String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Aviso'),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(context).pop();
            },
            child: Text('OK'),
          ),
        ],
      ),
    );
  }

  void _editEvent(BuildContext context, dynamic event) {
    final TextEditingController titleController =
    TextEditingController(text: event['title']);
    final TextEditingController descriptionController =
    TextEditingController(text: event['description']);
    final TextEditingController dateController =
    TextEditingController(text: event['date']);
    final TextEditingController timeController =
    TextEditingController(text: event['time']);
    final TextEditingController durationController =
    TextEditingController(text: event['duration']);

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Editar Evento'),
          content: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextField(
                  controller: titleController,
                  decoration: InputDecoration(labelText: 'Título'),
                ),
                SizedBox(height: 10),
                TextField(
                  controller: descriptionController,
                  decoration: InputDecoration(labelText: 'Descrição'),
                ),
                SizedBox(height: 10),
                TextField(
                  controller: dateController,
                  decoration: InputDecoration(labelText: 'Data'),
                ),
                SizedBox(height: 10),
                TextField(
                  controller: timeController,
                  decoration: InputDecoration(labelText: 'Horário'),
                ),
                SizedBox(height: 10),
                TextField(
                  controller: durationController,
                  decoration: InputDecoration(labelText: 'Duração'),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(); // Fechar modal
              },
              child: Text('Cancelar'),
            ),
            ElevatedButton(
              onPressed: () {
                setState(() {
                  event['title'] = titleController.text;
                  event['description'] = descriptionController.text;
                  event['date'] = dateController.text;
                  event['time'] = timeController.text;
                  event['duration'] = durationController.text;
                });
                Navigator.of(context).pop(); // Fechar modal após edição
              },
              child: Text('Salvar'),
            ),
          ],
        );
      },
    );
  }

  void _deleteEvent(BuildContext context, dynamic id, int index) async {
    if (id == null) {
      _showAlert(context, 'Erro: O evento não possui um identificador válido.');
      return;
    }

    try {
      final url =
          'https://web-qx4yu7fnv0m1.up-us-nyc1-k8s-1.apps.run-on-seenode.com/events/$id';
      final response = await http.delete(Uri.parse(url));

      if (response.statusCode == 200) {
        setState(() {
          events.removeAt(index);
        });
        _showAlert(context, 'Evento deletado com sucesso!');
      } else {
        _showAlert(context, 'Erro ao deletar evento: ${response.body}');
      }
    } catch (e) {
      _showAlert(context, 'Erro: $e');
    }
  }
  void _createAccount(BuildContext context) {
    final TextEditingController firstNameController = TextEditingController();
    final TextEditingController lastNameController = TextEditingController();
    final TextEditingController emailController = TextEditingController();
    final TextEditingController passwordController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Criar Conta'),
          content: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextField(
                  controller: firstNameController,
                  decoration: InputDecoration(
                    labelText: 'Nome',
                    border: OutlineInputBorder(),
                  ),
                ),
                SizedBox(height: 10),
                TextField(
                  controller: lastNameController,
                  decoration: InputDecoration(
                    labelText: 'Sobrenome',
                    border: OutlineInputBorder(),
                  ),
                ),
                SizedBox(height: 10),
                TextField(
                  controller: emailController,
                  decoration: InputDecoration(
                    labelText: 'Email',
                    border: OutlineInputBorder(),
                  ),
                  keyboardType: TextInputType.emailAddress,
                ),
                SizedBox(height: 10),
                TextField(
                  controller: passwordController,
                  decoration: InputDecoration(
                    labelText: 'Senha',
                    border: OutlineInputBorder(),
                  ),
                  obscureText: true,
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(); // Fechar modal
              },
              child: Text('Cancelar'),
            ),
            ElevatedButton(
              onPressed: () async {
                await _registerUser(
                  context,
                  firstNameController.text.trim(),
                  lastNameController.text.trim(),
                  emailController.text.trim(),
                  passwordController.text.trim(),
                );
                Navigator.of(context).pop(); // Fechar modal
              },
              child: Text('Criar Conta'),
            ),
          ],
        );
      },
    );
  }

  Future<void> _registerUser(BuildContext context, String firstName, String lastName, String email, String password) async {
    const String registerUrl =
        'https://web-qx4yu7fnv0m1.up-us-nyc1-k8s-1.apps.run-on-seenode.com/users';

    if (firstName.isEmpty || lastName.isEmpty || email.isEmpty || password.isEmpty) {
      _showAlert(context, 'Por favor, preencha todos os campos.');
      return;
    }

    try {
      final response = await http.post(
        Uri.parse(registerUrl),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'firstName': firstName,
          'lastName': lastName,
          'email': email,
          'password': password, // A senha será enviada como texto simples
        }),
      );

      if (response.statusCode == 201) {
        _showAlert(context, 'Conta criada com sucesso! Faça login para acessar.');
      } else {
        final responseBody = jsonDecode(response.body);
        final errorMessage = responseBody['message'] ?? 'Erro desconhecido';
        _showAlert(context, errorMessage);
      }
    } catch (e) {
      _showAlert(context, 'Erro ao criar conta: $e');
    }
  }

}
